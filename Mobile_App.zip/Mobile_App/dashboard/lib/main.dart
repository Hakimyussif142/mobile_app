import 'package:flutter/material.dart';

void main() {
  runApp(const CourseDashboardApp());
}

class CourseDashboardApp extends StatelessWidget {
  const CourseDashboardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Course Dashboard',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
        fontFamily: 'Poppins',
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  String _selectedCategory = "Science";

  // Animated button size
  double _buttonScale = 1.0;

  // Sample course list
  final List<Map<String, dynamic>> courses = [
    {"name": "Flutter Development", "instructor": "Mr. Mensah", "icon": Icons.phone_android},
    {"name": "Database Systems", "instructor": "Dr. Kwame", "icon": Icons.storage},
    {"name": "Web Development", "instructor": "Ms. Akua", "icon": Icons.web},
    {"name": "Cyber Security", "instructor": "Dr. Adjei", "icon": Icons.security},
    {"name": "Data Science", "instructor": "Prof. Owusu", "icon": Icons.analytics},
  ];

  void _logoutDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Logout Confirmation"),
        content: const Text("Are you sure you want to exit the app?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("No"),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Logged out successfully."),
                ),
              );
            },
            child: const Text("Yes"),
          ),
        ],
      ),
    );
  }

  Widget _buildHome() {
    return Center(
      child: AnimatedOpacity(
        opacity: _currentIndex == 0 ? 1.0 : 0.0,
        duration: const Duration(milliseconds: 500),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.home, size: 100, color: Colors.deepPurple.shade400),
            const SizedBox(height: 12),
            Text(
              "Welcome to the Course Dashboard!",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _logoutDialog,
              icon: const Icon(Icons.exit_to_app),
              label: const Text("Logout"),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildCourses() {
    return Column(
      children: [
        const SizedBox(height: 12),
        DropdownButton<String>(
          value: _selectedCategory,
          icon: const Icon(Icons.arrow_drop_down),
          items: ["Science", "Arts", "Technology"]
              .map((cat) => DropdownMenuItem(
            value: cat,
            child: Text(cat),
          ))
              .toList(),
          onChanged: (val) {
            setState(() {
              _selectedCategory = val!;
            });
          },
        ),
        Text(
          "Selected Category: $_selectedCategory",
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const Divider(),
        Expanded(
          child: ListView.builder(
            itemCount: courses.length,
            itemBuilder: (ctx, i) {
              final course = courses[i];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(course["icon"], color: Colors.deepPurple),
                  title: Text(course["name"]),
                  subtitle: Text("Instructor: ${course["instructor"]}"),
                  trailing: IconButton(
                    icon: const Icon(Icons.arrow_forward_ios, size: 18),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Opening ${course["name"]}...")),
                      );
                    },
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 20),
        // Animated enroll button
        AnimatedScale(
          scale: _buttonScale,
          duration: const Duration(milliseconds: 300),
          child: FloatingActionButton.extended(
            onPressed: () {
              setState(() => _buttonScale = 1.2);
              Future.delayed(const Duration(milliseconds: 200), () {
                setState(() => _buttonScale = 1.0);
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Enrolled successfully!")),
              );
            },
            icon: const Icon(Icons.school),
            label: const Text("Enroll"),
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildProfile() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircleAvatar(
            radius: 60,
            backgroundImage: NetworkImage(
              "https://cdn-icons-png.flaticon.com/512/3135/3135755.png",
            ),
          ),
          const SizedBox(height: 12),
          Text(
            "Hakim",
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            "Information Technology Student",
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: _logoutDialog,
            icon: const Icon(Icons.logout),
            label: const Text("Logout"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      _buildHome(),
      _buildCourses(),
      _buildProfile(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          ["Home", "Courses", "Profile"][_currentIndex],
        ),
        centerTitle: true,
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 500),
        child: screens[_currentIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.deepPurple,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: "Courses"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}
